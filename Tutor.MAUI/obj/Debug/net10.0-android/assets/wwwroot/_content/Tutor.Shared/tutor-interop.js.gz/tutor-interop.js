        function autoGrowTextarea(element) {
            if (element) {
                element.style.height = 'auto';
                element.style.height = Math.min(element.scrollHeight, 200) + 'px';
            }
        }
        function resetTextareaHeight(element) {
            if (element) {
                element.style.height = 'auto';
            }
        }
        function setupTextareaEnterHandler(element, dotNetRef, enterToSend) {
            if (element) {
                element.addEventListener('keydown', async function(e) {
                    if (e.key === 'Enter' && !e.shiftKey && enterToSend) {
                        e.preventDefault();
                        await dotNetRef.invokeMethodAsync('SendFromJs');
                    }
                });
            }
        }
        function scrollToBottom(element) {
            if (element) {
                element.scrollTop = element.scrollHeight;
            }
        }
        function focusElement(element) {
            if (element) {
                element.focus();
            }
        }
        function setupTabFocus(element) {
            if (element) {
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Tab' && !e.shiftKey && document.activeElement !== element) {
                        e.preventDefault();
                        element.focus();
                    }
                });
            }
        }
        function setTheme(theme) {
            document.documentElement.setAttribute('data-theme', theme);
        }
        function getTheme() {
            return document.documentElement.getAttribute('data-theme') || 'Light';
        }
        function setBorderRadius(px) {
            document.documentElement.style.setProperty('--border-radius', px + 'px');
        }
        function getBorderRadius() {
            var value = getComputedStyle(document.documentElement).getPropertyValue('--border-radius');
            return parseInt(value) || 6;
        }
        function setParagraphSpacing(em) {
            document.documentElement.style.setProperty('--paragraph-spacing', em + 'em');
        }
        function getParagraphSpacing() {
            var value = getComputedStyle(document.documentElement).getPropertyValue('--paragraph-spacing');
            return parseFloat(value) || 0.8;
        }
        
        // Panel drag/resize handling
        var panelDragDotNetRef = null;
        function setupPanelDragHandler(dotNetRef) {
            panelDragDotNetRef = dotNetRef;
            
            document.addEventListener('mousemove', function(e) {
                if (panelDragDotNetRef) {
                    panelDragDotNetRef.invokeMethodAsync('OnPanelMouseMove', e.clientX, e.clientY);
                }
            });
            
            document.addEventListener('mouseup', function(e) {
                if (panelDragDotNetRef) {
                    panelDragDotNetRef.invokeMethodAsync('OnPanelMouseUp');
                }
            });
        }
        
        // Term click handler for clickable bold terms
        var termClickDotNetRef = null;
        function setupTermClickHandler(dotNetRef) {
            termClickDotNetRef = dotNetRef;
            window.askAboutTerm = function(term) {
                if (termClickDotNetRef) {
                    termClickDotNetRef.invokeMethodAsync('AskAboutTerm', term);
                }
            };
        }




        // D3.js Force Directed Graph for Knowledge Base visualization
        var forceGraphDotNetRef = null;
        var forceSimulation = null;
        var forceGraphSvg = null;
        var forceGraphG = null;
        var forceGraphZoom = null;
        var forceGraphNodes = null;
        var contextMenuNode = null; // Track which node the context menu is for
        var pinnedNodes = {}; // Track pinned node positions globally

        // Context Menu Functions
        function showContextMenu(x, y, nodeData) {
            var menu = document.getElementById('graph-context-menu');
            if (!menu) return;
            
            contextMenuNode = nodeData;
            
            // Update menu title with node name
            var titleEl = menu.querySelector('.context-menu-title');
            if (titleEl && nodeData) {
                titleEl.textContent = nodeData.title.length > 25 
                    ? nodeData.title.substring(0, 25) + '...' 
                    : nodeData.title;
            }
            
            // Update pin/unpin menu item based on current state
            var pinButton = menu.querySelector('[data-action="pin"]');
            if (pinButton && nodeData) {
                var isPinned = pinnedNodes && pinnedNodes[nodeData.id] != null;
                var iconEl = pinButton.querySelector('.bi');
                var textEl = pinButton.querySelectorAll('span')[1];
                
                if (isPinned) {
                    if (iconEl) {
                        iconEl.className = 'bi bi-pin-angle-fill';
                    }
                    if (textEl) {
                        textEl.textContent = 'Unpin Position';
                    }
                } else {
                    if (iconEl) {
                        iconEl.className = 'bi bi-pin-angle';
                    }
                    if (textEl) {
                        textEl.textContent = 'Pin Position';
                    }
                }
            }
            
            
            // Position the menu relative to its parent container
            var wrapper = menu.parentElement;
            var wrapperRect = wrapper ? wrapper.getBoundingClientRect() : { left: 0, top: 0 };
            
            // Convert page coordinates to container-relative coordinates
            var relativeX = x - wrapperRect.left;
            var relativeY = y - wrapperRect.top;
            
            // Position the menu first to measure it
            menu.style.display = 'block';
            
            // Adjust position to keep menu in viewport
            var menuRect = menu.getBoundingClientRect();
            var wrapperWidth = wrapper ? wrapper.clientWidth : window.innerWidth;
            var wrapperHeight = wrapper ? wrapper.clientHeight : window.innerHeight;
            
            // Keep within the wrapper bounds
            if (relativeX + menuRect.width > wrapperWidth) {
                relativeX = wrapperWidth - menuRect.width - 10;
            }
            if (relativeY + menuRect.height > wrapperHeight) {
                relativeY = wrapperHeight - menuRect.height - 10;
            }
            
            // Ensure not negative
            relativeX = Math.max(10, relativeX);
            relativeY = Math.max(10, relativeY);
            
            menu.style.left = relativeX + 'px';
            menu.style.top = relativeY + 'px';
            
            console.log('[Context Menu] Showing for node:', nodeData.title, 'at', relativeX, relativeY);
        }
        
        function hideContextMenu() {
            var menu = document.getElementById('graph-context-menu');
            if (menu) {
                menu.style.display = 'none';
            }
            contextMenuNode = null;
        }
        
        // Handle context menu item clicks
        function handleContextMenuAction(action) {
            if (!contextMenuNode) {
                console.log('[Context Menu] No node selected');
                hideContextMenu();
                return;
            }
            
            console.log('[Context Menu] Action:', action, 'on node:', contextMenuNode.title);
            
            switch (action) {
                case 'pin':
                    // Toggle pin state using the shared function
                    if (window.toggleNodePin && contextMenuNode) {
                        window.toggleNodePin(contextMenuNode.id);
                    }
                    break;
                    
                case 'focus':
                    // Pan to this node
                    panToNode(contextMenuNode.id);
                    break;
                    
                case 'expand':
                    // Placeholder - will be implemented to expand connections
                    console.log('[Context Menu] Expand connections - placeholder');
                    if (forceGraphDotNetRef) {
                        forceGraphDotNetRef.invokeMethodAsync('OnContextMenuAction', 'expand', contextMenuNode.id);
                    }
                    break;
                    
                case 'hide':
                    // Placeholder - will be implemented to hide node
                    console.log('[Context Menu] Hide node - placeholder');
                    if (forceGraphDotNetRef) {
                        forceGraphDotNetRef.invokeMethodAsync('OnContextMenuAction', 'hide', contextMenuNode.id);
                    }
                    break;
                    
                case 'isolate':
                    // Placeholder - will be implemented to isolate subgraph
                    console.log('[Context Menu] Isolate subgraph - placeholder');
                    if (forceGraphDotNetRef) {
                        forceGraphDotNetRef.invokeMethodAsync('OnContextMenuAction', 'isolate', contextMenuNode.id);
                    }
                    break;
                    
                case 'copy':
                    // Copy node name to clipboard
                    if (navigator.clipboard && contextMenuNode.title) {
                        navigator.clipboard.writeText(contextMenuNode.title).then(function() {
                            console.log('[Context Menu] Copied to clipboard:', contextMenuNode.title);
                        });
                    }
                    break;
                    
                default:
                    console.log('[Context Menu] Unknown action:', action);
            }
            
            hideContextMenu();
        }
        
        // Setup context menu event listeners (called once on page load)
        document.addEventListener('DOMContentLoaded', function() {
            // Close context menu on click anywhere
            document.addEventListener('click', function(e) {
                var menu = document.getElementById('graph-context-menu');
                if (menu && !menu.contains(e.target)) {
                    hideContextMenu();
                }
            });
            
            // Close context menu on Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    hideContextMenu();
                }
            });
            
            // Handle context menu item clicks using event delegation
            document.addEventListener('click', function(e) {
                var menuItem = e.target.closest('.context-menu-item');
                if (menuItem) {
                    var action = menuItem.getAttribute('data-action');
                    if (action) {
                        handleContextMenuAction(action);
                    }
                }
            });
        });

        // Calculate dynamic force parameters based on node count
        // Returns optimal linkDistance, chargeStrength, collisionRadius, and spokeRadius
        function calculateForceParams(nodeCount) {
            // Base parameters for a "standard" graph of ~500 nodes
            var baseNodeCount = 500;
            
            // Scale factor: larger for fewer nodes, smaller for more nodes
            // Use logarithmic scaling for smoother transitions
            var scaleFactor = Math.max(0.3, Math.min(3, Math.log10(baseNodeCount) / Math.log10(Math.max(10, nodeCount))));
            
            // For very small graphs (< 50 nodes), boost spacing more aggressively
            if (nodeCount < 50) {
                scaleFactor = Math.max(scaleFactor, 2.5 - (nodeCount / 50) * 1.5);
            }
            
            // Calculate parameters
            var linkDistance = Math.round(80 * scaleFactor + 40); // Range: 64-280
            var chargeStrength = Math.round(-200 * scaleFactor - 100); // Range: -160 to -700
            var collisionRadius = Math.round(30 * scaleFactor + 15); // Range: 24-105
            var spokeRadius = Math.round(150 * scaleFactor + 50); // Range: 95-500
            
            console.log('[calculateForceParams] nodeCount=' + nodeCount + ', scaleFactor=' + scaleFactor.toFixed(2) +
                ', linkDistance=' + linkDistance + ', charge=' + chargeStrength + 
                ', collision=' + collisionRadius + ', spokeRadius=' + spokeRadius);
            
            return {
                linkDistance: linkDistance,
                chargeStrength: chargeStrength,
                collisionRadius: collisionRadius,
                spokeRadius: spokeRadius,
                scaleFactor: scaleFactor
            };
        }

        function initForceGraph(container, nodes, links, dotNetRef) {
            // Validate container element
            if (!container || !container.clientWidth) {
                console.warn('initForceGraph: Invalid container element');
                return;
            }
            
            
            forceGraphDotNetRef = dotNetRef;
            
            // Clear any existing graph
            container.innerHTML = '';
            
            var width = container.clientWidth || 800;
            var height = container.clientHeight || 500;

            // Color scale for node groups
            var color = d3.scaleOrdinal(d3.schemeCategory10);

            // Create SVG
            forceGraphSvg = d3.select(container)
                .append('svg')
                .attr('width', '100%')
                .attr('height', '100%')
                .attr('viewBox', [0, 0, width, height]);

            // Add zoom behavior
            forceGraphG = forceGraphSvg.append('g');
            forceGraphZoom = d3.zoom()
                .scaleExtent([0.1, 4])
                .on('zoom', function(event) {
                    forceGraphG.attr('transform', event.transform);
                });
                forceGraphSvg.call(forceGraphZoom);

                // Calculate dynamic force parameters based on node count
                var forceParams = calculateForceParams(nodes.length);

                // Create force simulation
                forceSimulation = d3.forceSimulation(nodes)
                    .force('link', d3.forceLink(links).id(function(d) { return d.id; }).distance(forceParams.linkDistance))
                    .force('charge', d3.forceManyBody().strength(forceParams.chargeStrength))
                    .force('center', d3.forceCenter(width / 2, height / 2))
                    .force('collision', d3.forceCollide().radius(forceParams.collisionRadius));

            // Create links
            var link = forceGraphG.append('g')
                .attr('class', 'links')
                .selectAll('line')
                .data(links)
                .enter().append('line')
                .attr('class', function(d) { return 'link ' + (d.type || '').toLowerCase(); })
                .attr('stroke', '#999')
                .attr('stroke-opacity', 0.6)
                .attr('stroke-width', 2);

            // Compute edge count per node for StreetSamurai-style sizing
            var edgeCounts = {};
            links.forEach(function(l) {
                var srcId = typeof l.source === 'object' ? l.source.id : l.source;
                var tgtId = typeof l.target === 'object' ? l.target.id : l.target;
                edgeCounts[srcId] = (edgeCounts[srcId] || 0) + 1;
                edgeCounts[tgtId] = (edgeCounts[tgtId] || 0) + 1;
            });
            nodes.forEach(function(n) { n.edgeCount = edgeCounts[n.id] || 0; });

            // StreetSamurai node radius formula
            function nodeRadius(d) {
                return Math.min(6 + (d.edgeCount || 0) * 0.8, 28);
            }

            // Create nodes
            var nodeGroups = forceGraphG.append('g')
                .attr('class', 'nodes')
                .selectAll('g')
                .data(nodes)
                .enter().append('g')
                .attr('class', 'node')
                .call(d3.drag()
                    .on('start', dragstarted)
                    .on('drag', dragged)
                    .on('end', dragended));

            // Store reference to all node groups (not just enter selection)
            forceGraphNodes = forceGraphG.select('.nodes').selectAll('.node');

            // Add squares to nodes (StreetSamurai style)
            nodeGroups.append('rect')
                .attr('width', function(d) { return nodeRadius(d) * 2; })
                .attr('height', function(d) { return nodeRadius(d) * 2; })
                .attr('x', function(d) { return -nodeRadius(d); })
                .attr('y', function(d) { return -nodeRadius(d); })
                .attr('rx', 3).attr('ry', 3)
                .attr('fill', function(d) { return color(d.group); })
                .attr('stroke', '#222')
                .attr('stroke-width', 1.5);

            // Add labels to nodes
            nodeGroups.append('text')
                .attr('dy', function(d) { return nodeRadius(d) + 15; })
                .attr('text-anchor', 'middle')
                .attr('class', 'node-label')
                .text(function(d) {
                    return d.title.length > 15 ? d.title.substring(0, 15) + '...' : d.title;
                });



            // Add click handler and track selected node for keyboard interactions
            var selectedNode = null;
            var selectedNodeId = null; // Track by ID to handle re-selection
            
            forceGraphNodes.on('click', function(event, d) {
                event.stopPropagation();
                
                // Hide context menu if open
                hideContextMenu();
                
                // Print node info to console for debugging/floating panel
                var isPinned = pinnedNodes[d.id] != null;
                console.log('[D3 Force Graph] Node selected:');
                console.log('  ID:', d.id);
                console.log('  Title:', d.title);
                console.log('  Group:', d.group);
                console.log('  Position: x=' + Math.round(d.x) + ', y=' + Math.round(d.y));
                console.log('  Pinned:', isPinned);
                
                // Store selection before async call
                selectedNode = d;
                selectedNodeId = d.id;
                highlightNodeElement(d3.select(this));
                
                // Notify Blazor after local state is set
                if (forceGraphDotNetRef) {
                    forceGraphDotNetRef.invokeMethodAsync('OnNodeClick', d.id);
                }
            });

            // Right-click context menu handler
            forceGraphNodes.on('contextmenu', function(event, d) {
                event.preventDefault();
                event.stopPropagation();
                
                selectedNode = d;
                selectedNodeId = d.id;
                highlightNodeElement(d3.select(this));
                
                // Notify Blazor of selection
                if (forceGraphDotNetRef) {
                    forceGraphDotNetRef.invokeMethodAsync('OnNodeClick', d.id);
                }
                
                showContextMenu(event.pageX, event.pageY, d);
            });

            // Keyboard handler for pin/unpin with "P" key
            d3.select(window).on('keydown.forceGraphPin', function(event) {
                // Prefer the currently dragged node, fall back to selected node
                var targetNode = currentlyDraggedNode || selectedNode;
                if (!targetNode) return;

                // Only react to "p" or "P" key
                var key = event.key || event.keyCode;
                if (key === 'p' || key === 'P' || key === 80) {
                    toggleNodePin(targetNode);
                }
            });

            // Update positions on each tick
            forceSimulation.on('tick', function() {
                link
                    .attr('x1', function(d) { return d.source.x; })
                    .attr('y1', function(d) { return d.source.y; })
                    .attr('x2', function(d) { return d.target.x; })
                    .attr('y2', function(d) { return d.target.y; });

                forceGraphNodes.attr('transform', function(d) { 
                    return 'translate(' + d.x + ',' + d.y + ')'; 
                });
            });

            // Track if node was pinned before drag started
            var wasPinnedBeforeDrag = false;
            // Track currently dragged node for hotkey support
            var currentlyDraggedNode = null;
            
            function dragstarted(event, d) {
                if (!event.active) forceSimulation.alphaTarget(0.3).restart();
                // Check if this node was pinned before dragging
                wasPinnedBeforeDrag = pinnedNodes[d.id] != null;
                // Track the dragged node for hotkey pinning
                currentlyDraggedNode = d;
                d.fx = d.x;
                d.fy = d.y;
            }

            function dragged(event, d) {
                d.fx = event.x;
                d.fy = event.y;
            }

            function dragended(event, d) {
                if (!event.active) forceSimulation.alphaTarget(0);
                
                // Clear the dragged node reference
                currentlyDraggedNode = null;
                
                // If the node was pinned before dragging, keep it pinned at the new position
                if (wasPinnedBeforeDrag || pinnedNodes[d.id] != null) {
                    // Update the pinned position to the new location
                    pinnedNodes[d.id] = { x: d.x, y: d.y };
                    d.fx = d.x;
                    d.fy = d.y;
                    
                    // Save pinned state
                    savePinnedNodes();
                    
                    console.log('[D3 Force Graph] Pinned node moved to new position:', d.title, Math.round(d.x), Math.round(d.y));
                } else {
                    // Node was not pinned, release it
                    d.fx = null;
                    d.fy = null;
                }
            }
            
            // Add or remove pin icon on a node
            function updatePinIcon(node, pinned) {
                var nodeEl = d3.selectAll('.node').filter(function(d) { return d.id === node.id; });
                nodeEl.select('.pin-icon').remove();
                if (pinned) {
                    var r = Math.min(6 + (node.edgeCount || 0) * 0.8, 28);
                    nodeEl.append('text')
                        .attr('class', 'pin-icon')
                        .attr('x', r - 3)
                        .attr('y', -r + 3)
                        .attr('text-anchor', 'end')
                        .attr('dominant-baseline', 'hanging')
                        .attr('font-size', '10px')
                        .attr('fill', '#fff')
                        .attr('pointer-events', 'none')
                        .text('\uD83D\uDCCC');
                }
            }

            // Toggle pin state for a node
            function toggleNodePin(node) {
                var isPinned = pinnedNodes[node.id] != null;
                if (isPinned) {
                    // Unpin: remove from pinned list and release fixed positions
                    delete pinnedNodes[node.id];
                    node.fx = null;
                    node.fy = null;
                    console.log('[D3 Force Graph] Node unpinned:', node.title);
                } else {
                    // Pin: add to pinned list and fix at current location
                    pinnedNodes[node.id] = { x: node.x, y: node.y };
                    node.fx = node.x;
                    node.fy = node.y;
                    console.log('[D3 Force Graph] Node pinned:', node.title, 'at', Math.round(node.x), Math.round(node.y));
                }

                // Update pin icon
                updatePinIcon(node, !isPinned);

                // Nudge simulation so layout updates
                if (forceSimulation) {
                    forceSimulation.alphaTarget(0.3).restart();
                    setTimeout(function() { forceSimulation.alphaTarget(0); }, 300);
                }
                
                // Save pinned state
                savePinnedNodes();
                
                // Notify Blazor of pin state change
                if (forceGraphDotNetRef) {
                    forceGraphDotNetRef.invokeMethodAsync('OnNodePinStateChanged', node.id, !isPinned, node.x, node.y);
                }
            }
            
            // Make toggleNodePin accessible globally for context menu
            window.toggleNodePin = function(nodeId) {
                var node = nodes.find(function(n) { return n.id === nodeId; });
                if (node) {
                    toggleNodePin(node);
                }
            };
            
            // Save pinned nodes to localStorage
            function savePinnedNodes() {
                try {
                    localStorage.setItem('pinnedNodes', JSON.stringify(pinnedNodes));
                } catch (e) {
                    console.warn('[D3 Force Graph] Could not save pinned nodes:', e);
                }
            }
            
            // Load pinned nodes from localStorage
            function loadPinnedNodes() {
                try {
                    var saved = localStorage.getItem('pinnedNodes');
                    if (saved) {
                        pinnedNodes = JSON.parse(saved);
                        // Apply pinned positions and pin icons to nodes
                        nodes.forEach(function(node) {
                            if (pinnedNodes[node.id]) {
                                node.fx = pinnedNodes[node.id].x;
                                node.fy = pinnedNodes[node.id].y;
                                node.x = pinnedNodes[node.id].x;
                                node.y = pinnedNodes[node.id].y;
                                updatePinIcon(node, true);
                            }
                        });
                        console.log('[D3 Force Graph] Loaded', Object.keys(pinnedNodes).length, 'pinned nodes');
                    }
                } catch (e) {
                    console.warn('[D3 Force Graph] Could not load pinned nodes:', e);
                }
            }
            
            // Load saved pinned state
            loadPinnedNodes();
            
            // Setup resize handler for this graph
            setupForceGraphResize(container);
        }

        // Resize handling for D3.js graph
        var forceGraphContainer = null;
        var resizeDebounceTimer = null;
        var forceGraphResizeObserver = null;
        
        function setupForceGraphResize(container) {
            forceGraphContainer = container;
            
            // Clean up any existing observer
            if (forceGraphResizeObserver) {
                forceGraphResizeObserver.disconnect();
            }
            
            // Use ResizeObserver for more accurate container resize detection
            if (window.ResizeObserver) {
                forceGraphResizeObserver = new ResizeObserver(function(entries) {
                    for (var entry of entries) {
                        // Check if size actually changed to avoid unnecessary updates
                        var newWidth = entry.contentRect.width;
                        var newHeight = entry.contentRect.height;
                        if (newWidth > 0 && newHeight > 0) {
                            debounceResizeForceGraph();
                        }
                    }
                });
                forceGraphResizeObserver.observe(container);
            }
            
            // Also listen for window resize as fallback
            window.removeEventListener('resize', debounceResizeForceGraph);
            window.addEventListener('resize', debounceResizeForceGraph);
            
            // Listen for visibility changes (e.g., tab switches, panel toggles)
            document.removeEventListener('visibilitychange', handleVisibilityChange);
            document.addEventListener('visibilitychange', handleVisibilityChange);
            
            // MutationObserver to detect when parent containers change size/visibility
            if (window.MutationObserver) {
                var parent = container.parentElement;
                while (parent && parent !== document.body) {
                    var mutationObserver = new MutationObserver(function(mutations) {
                        mutations.forEach(function(mutation) {
                            if (mutation.type === 'attributes' && 
                                (mutation.attributeName === 'class' || mutation.attributeName === 'style')) {
                                // Slight delay to let CSS transitions complete
                                setTimeout(debounceResizeForceGraph, 50);
                            }
                        });
                    });
                    mutationObserver.observe(parent, { attributes: true });
                    parent = parent.parentElement;
                }
            }
        }
        
        function handleVisibilityChange() {
            if (!document.hidden && forceGraphContainer) {
                // Re-measure and resize when page becomes visible
                setTimeout(resizeForceGraph, 100);
            }
        }
        
        function debounceResizeForceGraph() {
            if (resizeDebounceTimer) {
                clearTimeout(resizeDebounceTimer);
            }
            resizeDebounceTimer = setTimeout(resizeForceGraph, 100);
        }
        
        function resizeForceGraph() {
            if (!forceGraphContainer || !forceGraphSvg || !forceSimulation) return;
            
            // Get actual container dimensions
            var rect = forceGraphContainer.getBoundingClientRect();
            var width = rect.width || forceGraphContainer.clientWidth || 800;
            var height = rect.height || forceGraphContainer.clientHeight || 500;
            
            // Skip if dimensions are invalid (container hidden or collapsed)
            if (width <= 0 || height <= 0) return;
            
            console.log('[D3 Force Graph] Resizing to:', width + 'x' + height);
            
            // Update SVG viewBox
            forceGraphSvg.attr('viewBox', [0, 0, width, height]);
            
            // Update center force to new dimensions
            forceSimulation.force('center', d3.forceCenter(width / 2, height / 2));
            
            // Gently restart simulation to adjust layout
            forceSimulation.alpha(0.3).restart();
        }
        
        // Force immediate resize (can be called from C#)
        function forceResizeGraph() {
            if (resizeDebounceTimer) {
                clearTimeout(resizeDebounceTimer);
            }
            resizeForceGraph();
        }


        // Track pending highlight timer to prevent selection reversion
        var pendingHighlightTimer = null;

        function cancelPendingHighlight() {
            if (pendingHighlightTimer) {
                clearTimeout(pendingHighlightTimer);
                pendingHighlightTimer = null;
            }
        }

        function highlightNodeElement(nodeElement) {
            // Cancel any pending highlight from previous selection
            cancelPendingHighlight();
            // Reset all nodes
            d3.selectAll('.node rect').attr('stroke', '#222').attr('stroke-width', 1.5);
            // Highlight the selected node
            nodeElement.select('rect').attr('stroke', '#ffc107').attr('stroke-width', 4);
        }

        function highlightNode(nodeId) {
            if (!forceSimulation) return;
            // Cancel any pending highlight from previous selection
            cancelPendingHighlight();
            d3.selectAll('.node rect').attr('stroke', '#222').attr('stroke-width', 1.5);
            d3.selectAll('.node').filter(function(d) { return d.id === nodeId; })
                .select('rect').attr('stroke', '#ffc107').attr('stroke-width', 4);
        }

        function panToNode(nodeId) {
            if (!forceSimulation || !forceGraphSvg || !forceGraphZoom) return;
            
            // Find the node with the matching ID
            var targetNode = null;
            forceGraphNodes.each(function(d) {
                if (d.id === nodeId) {
                    targetNode = d;
                }
            });
            
            if (!targetNode) return;
            
            // Get the SVG dimensions
            var svgElement = forceGraphSvg.node();
            var width = svgElement.clientWidth || 800;
            var height = svgElement.clientHeight || 500;
            
            // Calculate the transform to center on the node
            var scale = 1.5; // Zoom in a bit when focusing
            var x = width / 2 - targetNode.x * scale;
            var y = height / 2 - targetNode.y * scale;
            
            // Smoothly transition to the new view
            forceGraphSvg.transition()
                .duration(750)
                .ease(d3.easeCubicInOut)
                .call(
                    forceGraphZoom.transform,
                    d3.zoomIdentity.translate(x, y).scale(scale)
                );
            
            // Highlight the node after a small delay (store timer so it can be cancelled)
            pendingHighlightTimer = setTimeout(function() {
                pendingHighlightTimer = null;
                highlightNode(nodeId);
            }, 400);
        }

        // Store reference to links for filtering
        var forceGraphLinks = null;
        var allNodesData = null;
        var allLinksData = null;
        var hiddenNodeIds = new Set(); // Track which nodes are hidden

        // Override initForceGraph to store links reference
        var originalInitForceGraph = initForceGraph;
        initForceGraph = function(container, nodes, links, dotNetRef) {
            allNodesData = nodes;
            allLinksData = links;
            hiddenNodeIds.clear();
            originalInitForceGraph(container, nodes, links, dotNetRef);
            // Store link selection after graph is created
            forceGraphLinks = forceGraphG ? forceGraphG.select('.links').selectAll('line') : null;
        };

        // Filter the graph to show only specified node IDs
        // Keeps nodes in their natural positions - only hides non-matching nodes
        // primaryNodeId: the node to pan the camera to (typically the best search match)
        function filterGraphByNodes(visibleNodeIds, primaryNodeId) {
            if (!forceGraphNodes || !forceGraphG || !forceSimulation) {
                console.log('[filterGraphByNodes] Missing required elements:', {
                    forceGraphNodes: !!forceGraphNodes,
                    forceGraphG: !!forceGraphG,
                    forceSimulation: !!forceSimulation
                });
                return;
            }

            console.log('[filterGraphByNodes] Filtering to show', visibleNodeIds.length, 'nodes');
            console.log('[filterGraphByNodes] Primary node to focus:', primaryNodeId);

            // Re-select nodes to ensure we have the latest
            forceGraphNodes = forceGraphG.select('.nodes').selectAll('.node');
            
            // Convert to Set for O(1) lookup
            var visibleSet = new Set(visibleNodeIds);
            hiddenNodeIds.clear();

            // Get SVG dimensions
            var viewBox = forceGraphSvg.attr('viewBox');
            var svgWidth = 800, svgHeight = 500;
            if (viewBox) {
                var parts = viewBox.split(',').map(function(s) { return parseFloat(s.trim()); });
                if (parts.length >= 4) {
                    svgWidth = parts[2];
                    svgHeight = parts[3];
                }
            }

            // Find the primary node's current position (for camera panning)
            var primaryNode = null;
            forceGraphNodes.each(function(d) {
                if (!d) return;
                if (d.id === primaryNodeId) {
                    primaryNode = d;
                }
                // Track hidden nodes
                if (!visibleSet.has(d.id)) {
                    hiddenNodeIds.add(d.id);
                }
            });

            console.log('[filterGraphByNodes] Primary node position:', 
                primaryNode ? (primaryNode.x + ',' + primaryNode.y) : 'not found');

            // Calculate dynamic force parameters based on VISIBLE node count
            var forceParams = calculateForceParams(visibleNodeIds.length);

            // DON'T reposition nodes - keep them where they naturally are
            // Just freeze hidden nodes so they don't affect physics
            forceGraphNodes.each(function(d) {
                if (!d) return;
                
                if (visibleSet.has(d.id)) {
                    // VISIBLE NODE: Keep natural position, allow physics to adjust gently
                    d.fx = null;
                    d.fy = null;
                } else {
                    // HIDDEN NODE: Fix in place so it doesn't affect visible nodes
                    d.fx = d.x;
                    d.fy = d.y;
                    d.vx = 0;
                    d.vy = 0;
                }
            });

            // Update node visibility (CSS display)
            forceGraphNodes
                .style('display', function(d) {
                    return d && visibleSet.has(d.id) ? null : 'none';
                })
                .attr('pointer-events', function(d) {
                    return d && visibleSet.has(d.id) ? 'all' : 'none';
                });

            // Update link visibility
            forceGraphG.select('.links').selectAll('line')
                .style('display', function(d) {
                    var sourceId = typeof d.source === 'object' ? d.source.id : d.source;
                    var targetId = typeof d.target === 'object' ? d.target.id : d.target;
                    return visibleSet.has(sourceId) && visibleSet.has(targetId) ? null : 'none';
                });

            // Reconfigure forces for the visible subset
            if (visibleNodeIds.length > 0) {
                // Filter links to ONLY include those between visible nodes
                var visibleLinks = allLinksData.filter(function(l) {
                    var sourceId = typeof l.source === 'object' ? l.source.id : l.source;
                    var targetId = typeof l.target === 'object' ? l.target.id : l.target;
                    return visibleSet.has(sourceId) && visibleSet.has(targetId);
                });

                console.log('[filterGraphByNodes] Visible links:', visibleLinks.length, 'of', allLinksData.length);

                // Configure forces - only apply to visible nodes
                // Keep center force but make it gentle so layout doesn't drift too much
                forceSimulation
                    .force('center', d3.forceCenter(svgWidth / 2, svgHeight / 2).strength(0.02))
                    .force('charge', d3.forceManyBody()
                        .strength(function(d) {
                            if (!visibleSet.has(d.id)) return 0;
                            return forceParams.chargeStrength;
                        }))
                    .force('link', d3.forceLink(visibleLinks)
                        .id(function(d) { return d.id; })
                        .distance(forceParams.linkDistance)
                        .strength(function(l) {
                            var sourceId = typeof l.source === 'object' ? l.source.id : l.source;
                            var targetId = typeof l.target === 'object' ? l.target.id : l.target;
                            if (!visibleSet.has(sourceId) || !visibleSet.has(targetId)) return 0;
                            return 0.3; // Gentler link strength to preserve layout
                        }))
                    .force('radial', null) // No radial force - keep natural layout
                    .force('collision', d3.forceCollide()
                        .radius(function(d) {
                            if (!visibleSet.has(d.id)) return 0;
                            return forceParams.collisionRadius;
                        }));

                // Very gentle restart - we want minimal movement, just settling
                forceSimulation.alpha(0.1).restart();
            }

            // PAN CAMERA to the primary node (don't move the node, move the camera!)
            if (primaryNode) {
                var svgNode = forceGraphSvg.node();
                var actualWidth = svgNode.clientWidth || svgWidth;
                var actualHeight = svgNode.clientHeight || svgHeight;
                
                // Use a moderate zoom level
                var scale = 1.2;
                
                // Calculate translation to center the PRIMARY NODE in the viewport
                var translateX = (actualWidth / 2) - (primaryNode.x * scale);
                var translateY = (actualHeight / 2) - (primaryNode.y * scale);
                
                console.log('[filterGraphByNodes] Panning camera to primary node:', {
                    nodePos: primaryNode.x + ',' + primaryNode.y,
                    scale: scale,
                    translate: translateX + ',' + translateY
                });

                // Smoothly pan to the primary node
                forceGraphSvg.transition()
                    .duration(750)
                    .ease(d3.easeCubicInOut)
                    .call(forceGraphZoom.transform, 
                        d3.zoomIdentity.translate(translateX, translateY).scale(scale));
            }

            // Highlight the primary node (store timer so it can be cancelled)
            if (primaryNodeId) {
                pendingHighlightTimer = setTimeout(function() {
                    pendingHighlightTimer = null;
                    highlightNode(primaryNodeId);
                }, 400);
            }
        }

        // Reset the graph filter to show all nodes
        function resetGraphFilter() {
            if (!forceGraphNodes || !forceGraphG || !forceSimulation) return;

            // Get SVG dimensions for center force
            var viewBox = forceGraphSvg.attr('viewBox');
            var svgWidth = 800, svgHeight = 500;
            if (viewBox) {
                var parts = viewBox.split(',').map(function(s) { return parseFloat(s.trim()); });
                if (parts.length >= 4) {
                    svgWidth = parts[2];
                    svgHeight = parts[3];
                }
            }

            // Count total nodes for dynamic parameters
            var totalNodeCount = 0;
            forceGraphNodes.each(function() { totalNodeCount++; });
            var forceParams = calculateForceParams(totalNodeCount);

            // Unfix ALL nodes (including any pinned primary node)
            forceGraphNodes.each(function(d) {
                d.fx = null;
                d.fy = null;
            });
            hiddenNodeIds.clear();

            // Restore all nodes visibility
            forceGraphNodes
                .style('display', null)
                .style('opacity', 1)
                .attr('pointer-events', 'all');

            // Restore all links visibility
            forceGraphG.select('.links').selectAll('line')
                .style('display', null)
                .style('opacity', 0.6);

            // Restore full physics with center force and dynamic parameters
            forceSimulation
                .force('center', d3.forceCenter(svgWidth / 2, svgHeight / 2))
                .force('charge', d3.forceManyBody().strength(forceParams.chargeStrength))
                .force('link', d3.forceLink(allLinksData).id(function(d) { return d.id; }).distance(forceParams.linkDistance))
                .force('radial', null) // Remove radial force used in filtered mode
                .force('collision', d3.forceCollide().radius(forceParams.collisionRadius));

            // Restart simulation
            forceSimulation.alpha(0.5).restart();

            // Reset zoom/pan
            if (forceGraphSvg && forceGraphZoom) {
                forceGraphSvg.transition()
                    .duration(500)
                    .call(
                        forceGraphZoom.transform,
                        d3.zoomIdentity.translate(0, 0).scale(1)
                    );
            }
        }

        // Clear all pinned nodes and release their fixed positions
        function clearAllPins() {
            if (!forceGraphNodes) return;
            
            console.log('[clearAllPins] Clearing all pinned nodes');
            
            // Clear the pinnedNodes object
            pinnedNodes = {};
            
            // Release all fixed positions and remove pin icons
            forceGraphNodes.each(function(d) {
                if (d) {
                    d.fx = null;
                    d.fy = null;
                }
            });
            d3.selectAll('.pin-icon').remove();

            // Clear localStorage
            try {
                localStorage.removeItem('pinnedNodes');
                console.log('[clearAllPins] Cleared localStorage pinnedNodes');
            } catch (e) {
                console.warn('[clearAllPins] Could not clear localStorage:', e);
            }
            
            // Nudge simulation to update layout
            if (forceSimulation) {
                forceSimulation.alpha(0.3).restart();
            }
        }

        // Center the view on visible nodes
        function centerOnVisibleNodes(visibleNodeIds) {
            if (!forceSimulation || !forceGraphSvg || !forceGraphZoom || !forceGraphNodes) return;

            var visibleSet = new Set(visibleNodeIds);
            var visibleNodes = [];

            forceGraphNodes.each(function(d) {
                if (d && visibleSet.has(d.id)) {
                    visibleNodes.push(d);
                }
            });

            console.log('[centerOnVisibleNodes] Found', visibleNodes.length, 'visible nodes');

            if (visibleNodes.length === 0) {
                console.log('[centerOnVisibleNodes] No visible nodes found, resetting view');
                // Reset to default view if no nodes found
                forceGraphSvg.transition()
                    .duration(500)
                    .call(forceGraphZoom.transform, d3.zoomIdentity);
                return;
            }

            // Calculate bounding box of visible nodes
            var minX = d3.min(visibleNodes, function(d) { return d.x; });
            var maxX = d3.max(visibleNodes, function(d) { return d.x; });
            var minY = d3.min(visibleNodes, function(d) { return d.y; });
            var maxY = d3.max(visibleNodes, function(d) { return d.y; });

            console.log('[centerOnVisibleNodes] Bounding box:', { minX: minX, maxX: maxX, minY: minY, maxY: maxY });

            // Handle edge cases where nodes are at same position or values are invalid
            if (!isFinite(minX) || !isFinite(maxX) || !isFinite(minY) || !isFinite(maxY)) {
                console.log('[centerOnVisibleNodes] Invalid bounding box values, using defaults');
                minX = 0; maxX = 100; minY = 0; maxY = 100;
            }
            if (minX === maxX) { minX -= 50; maxX += 50; }
            if (minY === maxY) { minY -= 50; maxY += 50; }

            var centerX = (minX + maxX) / 2;
            var centerY = (minY + maxY) / 2;
            var rangeX = Math.max(maxX - minX + 100, 200); // Add padding, minimum range
            var rangeY = Math.max(maxY - minY + 100, 200);

            // Get SVG dimensions from viewBox or element size
            var svgElement = forceGraphSvg.node();
            var viewBox = forceGraphSvg.attr('viewBox');
            var width, height;
            
            if (viewBox) {
                var parts = viewBox.split(',').map(function(s) { return parseFloat(s.trim()); });
                if (parts.length >= 4) {
                    width = parts[2];
                    height = parts[3];
                }
            }
            
            if (!width || !height || !isFinite(width) || !isFinite(height)) {
                width = svgElement.clientWidth || 800;
                height = svgElement.clientHeight || 500;
            }

            console.log('[centerOnVisibleNodes] SVG size:', width + 'x' + height);
            console.log('[centerOnVisibleNodes] Center:', centerX + ',' + centerY, 'Range:', rangeX + 'x' + rangeY);

            // Calculate scale to fit visible nodes with some padding
            var scaleX = (width * 0.8) / rangeX;  // Use 80% of width
            var scaleY = (height * 0.8) / rangeY; // Use 80% of height
            var scale = Math.min(scaleX, scaleY, 2); // Max zoom of 2
            scale = Math.max(scale, 0.1); // Min zoom of 0.1 (more aggressive for very spread out graphs)

            // Calculate translation to center the nodes
            var x = (width / 2) - (centerX * scale);
            var y = (height / 2) - (centerY * scale);

            // Ensure values are finite
            if (!isFinite(x)) x = 0;
            if (!isFinite(y)) y = 0;
            if (!isFinite(scale)) scale = 1;

            console.log('[centerOnVisibleNodes] Transform: translate(' + x + ',' + y + ') scale(' + scale + ')');

            forceGraphSvg.transition()
                .duration(750)
                .ease(d3.easeCubicInOut)
                .call(
                    forceGraphZoom.transform,
                    d3.zoomIdentity.translate(x, y).scale(scale)
                );
        }

        // Filter the graph by semantic similarity threshold
        // threshold: 0-1 value, links with similarity below this are hidden
        // Nodes that become disconnected (no visible links) are also hidden
        function filterBySimilarity(threshold) {
            if (!forceGraphNodes || !forceGraphG || !allLinksData) {
                console.log('[filterBySimilarity] Missing required elements');
                return;
            }
            
            console.log('[filterBySimilarity] Filtering with threshold:', threshold);
            
            // If threshold is 0, show everything
            if (threshold <= 0) {
                // Show all links
                forceGraphG.select('.links').selectAll('line')
                    .style('display', null)
                    .style('opacity', 0.6);
                
                // Show all nodes
                forceGraphNodes
                    .style('display', null)
                    .style('opacity', 1)
                    .attr('pointer-events', 'all');
                
                // Release any fixed positions from similarity filtering (but not pinned nodes)
                forceGraphNodes.each(function(d) {
                    if (d && !pinnedNodes[d.id]) {
                        d.fx = null;
                        d.fy = null;
                    }
                });
                
                if (forceSimulation) {
                    forceSimulation.alpha(0.3).restart();
                }
                return;
            }
            
            // Find links that meet the similarity threshold
            var visibleLinkSet = new Set();
            var connectedNodeIds = new Set();
            
            allLinksData.forEach(function(link) {
                // Use similarity score if available, otherwise use confidence, default to 0
                var similarity = link.similarity || link.confidence || 0;
                
                if (similarity >= threshold) {
                    var sourceId = typeof link.source === 'object' ? link.source.id : link.source;
                    var targetId = typeof link.target === 'object' ? link.target.id : link.target;
                    visibleLinkSet.add(sourceId + '->' + targetId);
                    connectedNodeIds.add(sourceId);
                    connectedNodeIds.add(targetId);
                }
            });
            
            console.log('[filterBySimilarity] Visible links:', visibleLinkSet.size, 'Connected nodes:', connectedNodeIds.size);
            
            // Update link visibility
            forceGraphG.select('.links').selectAll('line')
                .style('display', function(d) {
                    var sourceId = typeof d.source === 'object' ? d.source.id : d.source;
                    var targetId = typeof d.target === 'object' ? d.target.id : d.target;
                    var key = sourceId + '->' + targetId;
                    return visibleLinkSet.has(key) ? null : 'none';
                })
                .style('opacity', function(d) {
                    var sourceId = typeof d.source === 'object' ? d.source.id : d.source;
                    var targetId = typeof d.target === 'object' ? d.target.id : d.target;
                    var key = sourceId + '->' + targetId;
                    return visibleLinkSet.has(key) ? 0.6 : 0;
                });
            
            // Update node visibility - only show nodes that have visible connections
            forceGraphNodes
                .style('display', function(d) {
                    return d && connectedNodeIds.has(d.id) ? null : 'none';
                })
                .style('opacity', function(d) {
                    return d && connectedNodeIds.has(d.id) ? 1 : 0;
                })
                .attr('pointer-events', function(d) {
                    return d && connectedNodeIds.has(d.id) ? 'all' : 'none';
                });
            
            // Fix hidden nodes in place so they don't affect physics
            forceGraphNodes.each(function(d) {
                if (!d) return;
                
                if (connectedNodeIds.has(d.id)) {
                    // Visible node - keep physics unless pinned
                    if (!pinnedNodes[d.id]) {
                        d.fx = null;
                        d.fy = null;
                    }
                } else {
                    // Hidden node - fix in place
                    d.fx = d.x;
                    d.fy = d.y;
                    d.vx = 0;
                    d.vy = 0;
                }
            });
            
            // Restart simulation with gentler forces for the filtered subset
            if (forceSimulation) {
                forceSimulation.alpha(0.3).restart();
            }
        }
